/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package messageProtocol;

/**
 *
 * @author matheus
 */
public class HandShake extends ControlClass{

    public HandShake(String to, String from) {
        super("teste", to, from);
    }
    
    
    
}
