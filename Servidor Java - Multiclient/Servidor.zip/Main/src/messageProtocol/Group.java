/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package messageProtocol;

/**
 *
 * @author matheus
 */
public class Group extends ControlClass{

    public Group(String nomeGrupo, String to, String from) {
       
        super(nomeGrupo,to, from);
    }

    
   /* public void play() {
        
    }
    */
    
    
    
}
